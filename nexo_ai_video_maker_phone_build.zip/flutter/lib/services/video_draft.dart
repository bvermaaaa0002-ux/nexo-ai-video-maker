import 'package:flutter/foundation.dart';

class VideoDraft extends ChangeNotifier {
  String script = '';
  String voice = 'alloy';
  String style = 'cinematic mystery';
  String format = '16:9';

  void setScript(String value) {
    script = value;
    notifyListeners();
  }

  void setSettings({
    required String newVoice,
    required String newStyle,
    required String newFormat,
  }) {
    voice = newVoice;
    style = newStyle;
    format = newFormat;
    notifyListeners();
  }
}
