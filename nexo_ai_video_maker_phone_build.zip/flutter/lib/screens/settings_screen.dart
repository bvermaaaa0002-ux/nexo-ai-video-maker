import 'package:flutter/material.dart';
import '../widgets/gradient_button.dart';
import '../widgets/glass_card.dart';
import '../services/video_draft.dart';
import '../services/video_api.dart';

class SettingsScreen extends StatefulWidget {
  final VideoDraft draft;
  const SettingsScreen({super.key, required this.draft});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late String voice;
  late String style;
  late String format;
  bool starting = false;

  @override
  void initState() {
    super.initState();
    voice = widget.draft.voice;
    style = widget.draft.style;
    format = widget.draft.format;
  }

  Future<void> startGeneration() async {
    if (widget.draft.script.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('स्क्रिप्ट खाली है।')),
      );
      return;
    }

    setState(() => starting = true);
    widget.draft.setSettings(
      newVoice: voice,
      newStyle: style,
      newFormat: format,
    );

    try {
      final jobId = await VideoApi().createJob(
        script: widget.draft.script,
        voice: voice,
        style: style,
        format: format,
      );
      if (!mounted) return;
      Navigator.pushNamed(context, '/generating', arguments: jobId);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Generation शुरू नहीं हो सकी: $e')),
      );
    } finally {
      if (mounted) setState(() => starting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('वीडियो सेटिंग्स')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('1. Voice',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 17)),
          const SizedBox(height: 10),
          _choice('alloy', 'Natural voice', voice == 'alloy',
              () => setState(() => voice = 'alloy')),
          const SizedBox(height: 18),
          const Text('2. Video Style',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 17)),
          const SizedBox(height: 10),
          Wrap(spacing: 10, runSpacing: 10, children: [
            _choice('cinematic mystery', 'Cinematic', style == 'cinematic mystery',
                () => setState(() => style = 'cinematic mystery')),
            _choice('dark horror', 'Dark / Horror', style == 'dark horror',
                () => setState(() => style = 'dark horror')),
            _choice('documentary', 'Realistic', style == 'documentary',
                () => setState(() => style = 'documentary')),
          ]),
          const SizedBox(height: 18),
          const Text('3. Format',
              style: TextStyle(fontWeight: FontWeight.w700, fontSize: 17)),
          const SizedBox(height: 10),
          Wrap(spacing: 10, children: [
            _choice('16:9', 'YouTube', format == '16:9',
                () => setState(() => format = '16:9')),
            _choice('9:16', 'Shorts / Reels', format == '9:16',
                () => setState(() => format = '9:16')),
          ]),
          const SizedBox(height: 26),
          AbsorbPointer(
            absorbing: starting,
            child: GradientButton(
              text: starting ? 'शुरू हो रहा है...' : 'वीडियो जनरेट करें',
              icon: starting ? Icons.hourglass_top : Icons.auto_awesome,
              onPressed: startGeneration,
            ),
          ),
        ],
      ),
    );
  }

  Widget _choice(String title, String sub, bool selected, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        width: 160,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFF24123C) : const Color(0xFF12121E),
          borderRadius: BorderRadius.circular(15),
          border: Border.all(
            color: selected ? const Color(0xFFB34DFF) : Colors.white12,
          ),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(selected ? Icons.check_circle : Icons.circle_outlined,
              color: selected ? const Color(0xFFB34DFF) : Colors.white38),
          const SizedBox(height: 8),
          Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
          Text(sub, style: const TextStyle(color: Colors.white54, fontSize: 12)),
        ]),
      ),
    );
  }
}
