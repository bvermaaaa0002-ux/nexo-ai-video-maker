# NEXO AI Video Maker — Real AI Backend

This backend connects the Flutter UI to an AI pipeline.

## Pipeline
1. Script -> scene breakdown with an OpenAI text model.
2. Each scene -> Hindi narration with OpenAI text-to-speech.
3. Each scene -> short video with the OpenAI Videos API.
4. FFmpeg muxes narration into each clip and concatenates the clips.
5. Flutter polls `/api/jobs/{job_id}` until the final MP4 is ready.

OpenAI currently documents the Videos API with Sora 2/Sora 2 Pro and 4/8/12 second jobs, plus a content-download endpoint. The TTS endpoint supports text-to-speech generation. See the official docs linked in the main response.

## Run

Install FFmpeg on the server and make sure `ffmpeg` is on PATH.

Then:

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
copy .env.example .env   # Windows
# cp .env.example .env   # macOS/Linux
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Never put OPENAI_API_KEY inside the Android APK. Keep it on the server.

## Android emulator URL
For an Android emulator connecting to a backend running on the same computer, use:
`http://10.0.2.2:8000`

For a physical Android phone, use the computer/server's LAN IP or a deployed HTTPS backend.
