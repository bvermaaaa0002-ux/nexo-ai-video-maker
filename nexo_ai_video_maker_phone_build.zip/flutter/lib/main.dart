import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'screens/script_screen.dart';
import 'screens/settings_screen.dart';
import 'screens/generating_screen.dart';
import 'screens/scene_review_screen.dart';
import 'screens/preview_screen.dart';
import 'screens/export_screen.dart';
import 'services/video_draft.dart';

void main() {
  runApp(const NexoApp());
}

class NexoApp extends StatefulWidget {
  const NexoApp({super.key});

  @override
  State<NexoApp> createState() => _NexoAppState();
}

class _NexoAppState extends State<NexoApp> {
  final draft = VideoDraft();

  @override
  void dispose() {
    draft.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NEXO AI Video Maker',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF070711),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF9B4DFF),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      initialRoute: '/',
      onGenerateRoute: (settings) {
        switch (settings.name) {
          case '/':
            return MaterialPageRoute(builder: (_) => const HomeScreen());
          case '/script':
            return MaterialPageRoute(builder: (_) => ScriptScreen(draft: draft));
          case '/settings':
            return MaterialPageRoute(builder: (_) => SettingsScreen(draft: draft));
          case '/generating':
            final jobId = settings.arguments as String;
            return MaterialPageRoute(builder: (_) => GeneratingScreen(jobId: jobId));
          case '/scenes':
            return MaterialPageRoute(builder: (_) => const SceneReviewScreen());
          case '/preview':
            return MaterialPageRoute(builder: (_) => const PreviewScreen());
          case '/export':
            return MaterialPageRoute(builder: (_) => const ExportScreen());
          default:
            return MaterialPageRoute(builder: (_) => const HomeScreen());
        }
      },
    );
  }
}
