import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

class VideoJob {
  final String id;
  final String status;
  final int progress;
  final String? output;
  final String? error;

  const VideoJob({
    required this.id,
    required this.status,
    required this.progress,
    this.output,
    this.error,
  });

  bool get isCompleted => status == 'completed';
  bool get isFailed => status == 'failed';

  factory VideoJob.fromJson(String id, Map<String, dynamic> json) {
    return VideoJob(
      id: id,
      status: json['status']?.toString() ?? 'unknown',
      progress: (json['progress'] as num?)?.round() ?? 0,
      output: json['output']?.toString(),
      error: json['error']?.toString(),
    );
  }
}

class VideoApi {
  // Android Emulator -> backend running on the development computer.
  static const String baseUrl = 'http://10.0.2.2:8000';

  Future<String> createJob({
    required String script,
    required String voice,
    required String style,
    required String format,
  }) async {
    final response = await http.post(
      Uri.parse('$baseUrl/api/generate'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'script': script,
        'voice': voice,
        'style': style,
        'format': format,
        'generate_video': true,
      }),
    );

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Generate request failed: ${response.body}');
    }

    final data = jsonDecode(response.body) as Map<String, dynamic>;
    return data['job_id'].toString();
  }

  Future<VideoJob> getJob(String jobId) async {
    final response = await http.get(Uri.parse('$baseUrl/api/jobs/$jobId'));

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('Job status failed: ${response.body}');
    }

    return VideoJob.fromJson(
      jobId,
      jsonDecode(response.body) as Map<String, dynamic>,
    );
  }

  Stream<VideoJob> watchJob(
    String jobId, {
    Duration interval = const Duration(seconds: 3),
  }) async* {
    while (true) {
      final job = await getJob(jobId);
      yield job;

      if (job.isCompleted || job.isFailed) {
        return;
      }
      await Future<void>.delayed(interval);
    }
  }
}
