import 'package:flutter/material.dart';
import '../widgets/glass_card.dart';
import '../widgets/gradient_button.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const SizedBox(height: 30),
            const Icon(Icons.auto_awesome, size: 56, color: Color(0xFFB84CFF)),
            const SizedBox(height: 14),
            const Text(
              'NEXO AI Video Maker',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 8),
            const Text(
              'Script डालें और AI से वीडियो बनाएं',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white60, fontSize: 16),
            ),
            const SizedBox(height: 30),
            const GlassCard(
              child: Column(
                children: [
                  Icon(Icons.movie_creation_outlined,
                      size: 44, color: Color(0xFFB84CFF)),
                  SizedBox(height: 12),
                  Text('Script → Voice → AI Video',
                      style: TextStyle(fontWeight: FontWeight.w800)),
                  SizedBox(height: 6),
                  Text(
                    'आपकी स्क्रिप्ट backend को भेजकर generation job शुरू की जाएगी।',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white60),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            GradientButton(
              text: 'नई वीडियो बनाएँ',
              icon: Icons.add_circle_outline,
              onPressed: () => Navigator.pushNamed(context, '/script'),
            ),
          ],
        ),
      ),
    );
  }
}
