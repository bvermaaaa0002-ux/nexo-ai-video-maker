# Connect the existing Flutter Generate button

Add `http` to pubspec.yaml and copy `lib/services/video_api.dart` into your app.

Then, in `settings_screen.dart`, replace the current demo navigation with an API call:

```dart
final jobId = await VideoApi().create(
  script: 'YOUR_SCRIPT',
  voice: 'alloy',
  style: style,
  format: format,
);
if (context.mounted) {
  Navigator.pushNamed(context, '/generating', arguments: jobId);
}
```

For production, pass the actual script from your ScriptScreen using app state/provider rather than a global variable.
