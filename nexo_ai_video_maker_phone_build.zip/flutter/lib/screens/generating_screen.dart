import 'package:flutter/material.dart';
import '../services/video_api.dart';
import '../widgets/glass_card.dart';

class GeneratingScreen extends StatefulWidget {
  final String jobId;
  const GeneratingScreen({super.key, required this.jobId});

  @override
  State<GeneratingScreen> createState() => _GeneratingScreenState();
}

class _GeneratingScreenState extends State<GeneratingScreen> {
  VideoJob? job;
  String? error;

  @override
  void initState() {
    super.initState();
    _watch();
  }

  Future<void> _watch() async {
    try {
      await for (final value in VideoApi().watchJob(widget.jobId)) {
        if (!mounted) return;
        setState(() => job = value);

        if (value.isCompleted) {
          await Future<void>.delayed(const Duration(milliseconds: 400));
          if (!mounted) return;
          Navigator.pushReplacementNamed(
            context,
            '/preview',
            arguments: value.output,
          );
          return;
        }
        if (value.isFailed) {
          setState(() => error = value.error ?? 'Unknown backend error');
          return;
        }
      }
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    final progress = (job?.progress ?? 0) / 100.0;
    return Scaffold(
      appBar: AppBar(title: const Text('वीडियो जनरेट हो रहा है...')),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            SizedBox(
              width: 190,
              height: 190,
              child: Stack(alignment: Alignment.center, children: [
                SizedBox.expand(
                  child: CircularProgressIndicator(
                    value: progress,
                    strokeWidth: 10,
                    color: const Color(0xFFB84CFF),
                    backgroundColor: Colors.white10,
                  ),
                ),
                Text('${job?.progress ?? 0}%',
                    style: const TextStyle(
                        fontSize: 30, fontWeight: FontWeight.w800)),
              ]),
            ),
            const SizedBox(height: 28),
            GlassCard(
              child: Column(children: [
                Text(
                  error != null
                      ? 'Generation failed'
                      : (job?.status ?? 'Server से connection हो रहा है...'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
                if (error != null) ...[
                  const SizedBox(height: 10),
                  Text(error!, style: const TextStyle(color: Colors.redAccent)),
                  const SizedBox(height: 12),
                  OutlinedButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('वापस जाएँ'),
                  ),
                ],
              ]),
            ),
          ]),
        ),
      ),
    );
  }
}
