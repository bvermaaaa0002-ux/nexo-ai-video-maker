import os, json, uuid, subprocess, asyncio
from pathlib import Path
from typing import Optional
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from openai import OpenAI

load_dotenv()
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
OUTPUT_DIR = Path(os.getenv("OUTPUT_DIR", "outputs"))
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="NEXO AI Video Maker API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

JOBS = {}

class GenerateRequest(BaseModel):
    script: str = Field(min_length=1, max_length=100000)
    voice: str = "alloy"
    style: str = "cinematic mystery"
    format: str = "16:9"
    generate_video: bool = True

class GenerateResponse(BaseModel):
    job_id: str
    status: str

def parse_scenes(script: str, style: str):
    prompt = f"""Convert this Hindi YouTube script into 4-12 cinematic scenes.
Return ONLY valid JSON with this shape:
{{"scenes":[{{"title":"...","narration":"...","visual_prompt":"..."}}]}}
Keep narration in the original language. Visual prompts should be detailed and safe.
Style: {style}
SCRIPT:
{script}"""
    r = client.responses.create(
        model=os.getenv("OPENAI_TEXT_MODEL", "gpt-5"),
        input=prompt,
    )
    text = r.output_text.strip()
    try:
        data = json.loads(text)
    except Exception:
        start, end = text.find("{"), text.rfind("}")
        if start < 0 or end < 0:
            raise ValueError("Scene JSON could not be parsed")
        data = json.loads(text[start:end+1])
    return data["scenes"]

def safe_name(s):
    return "".join(c if c.isalnum() else "_" for c in s)[:60]

def tts(text: str, voice: str, out_path: Path):
    with client.audio.speech.with_streaming_response.create(
        model=os.getenv("OPENAI_TTS_MODEL", "gpt-4o-mini-tts"),
        voice=voice,
        input=text[:4096],
        instructions="Speak naturally in Hindi. Clear narration, documentary/cinematic tone.",
    ) as response:
        response.stream_to_file(out_path)

def create_video(prompt: str, size: str):
    video = client.videos.create(
        model=os.getenv("OPENAI_VIDEO_MODEL", "sora-2"),
        prompt=prompt,
        seconds="4",
        size=size,
    )
    return video.id

def poll_video(video_id: str):
    while True:
        v = client.videos.retrieve(video_id)
        if v.status == "completed":
            return v
        if v.status == "failed":
            raise RuntimeError(f"Video generation failed: {video_id}")
        import time
        time.sleep(5)

def download_video(video_id: str, out_path: Path):
    content = client.videos.download_content(video_id)
    content.write_to_file(out_path)

def mux_scene(video_path: Path, audio_path: Path, out_path: Path):
    subprocess.run([
        "ffmpeg", "-y", "-i", str(video_path), "-i", str(audio_path),
        "-c:v", "copy", "-c:a", "aac", "-shortest", str(out_path)
    ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

def concat_videos(paths, out_path: Path):
    list_file = out_path.with_suffix(".txt")
    list_file.write_text("\n".join(f"file '{p.resolve()}'" for p in paths), encoding="utf-8")
    subprocess.run([
        "ffmpeg", "-y", "-f", "concat", "-safe", "0",
        "-i", str(list_file), "-c", "copy", str(out_path)
    ], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

async def run_job(job_id: str, req: GenerateRequest):
    try:
        JOBS[job_id] = {"status": "parsing", "progress": 5, "scenes": []}
        scenes = parse_scenes(req.script, req.style)
        JOBS[job_id]["scenes"] = scenes
        scene_files = []
        size = "1280x720" if req.format == "16:9" else "720x1280"

        for i, scene in enumerate(scenes):
            JOBS[job_id].update(status=f"scene_{i+1}", progress=10 + int(i/max(1,len(scenes))*70))
            folder = OUTPUT_DIR / job_id
            folder.mkdir(parents=True, exist_ok=True)
            audio = folder / f"scene_{i+1}.mp3"
            raw = folder / f"scene_{i+1}_raw.mp4"
            muxed = folder / f"scene_{i+1}.mp4"

            await asyncio.to_thread(tts, scene["narration"], req.voice, audio)
            if req.generate_video:
                vid = await asyncio.to_thread(create_video, scene["visual_prompt"], size)
                await asyncio.to_thread(poll_video, vid)
                await asyncio.to_thread(download_video, vid, raw)
                await asyncio.to_thread(mux_scene, raw, audio, muxed)
                scene_files.append(muxed)

        final = OUTPUT_DIR / job_id / "final.mp4"
        if scene_files:
            await asyncio.to_thread(concat_videos, scene_files, final)

        JOBS[job_id].update(status="completed", progress=100, output=str(final))
    except Exception as e:
        JOBS[job_id].update(status="failed", progress=100, error=str(e))

@app.get("/health")
def health():
    return {"ok": True, "service": "nexo-ai-video-maker"}

@app.post("/api/generate", response_model=GenerateResponse)
async def generate(req: GenerateRequest):
    if not os.getenv("OPENAI_API_KEY"):
        raise HTTPException(500, "OPENAI_API_KEY is not configured on the server.")
    job_id = uuid.uuid4().hex
    JOBS[job_id] = {"status": "queued", "progress": 0}
    asyncio.create_task(run_job(job_id, req))
    return GenerateResponse(job_id=job_id, status="queued")

@app.get("/api/jobs/{job_id}")
def job_status(job_id: str):
    if job_id not in JOBS:
        raise HTTPException(404, "Job not found")
    return JOBS[job_id]
