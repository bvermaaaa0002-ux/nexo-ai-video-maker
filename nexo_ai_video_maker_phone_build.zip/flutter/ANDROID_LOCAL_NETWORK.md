# Android local backend setup

For local development, the app calls `http://10.0.2.2:8000` from the Android emulator.

In `android/app/src/main/AndroidManifest.xml`, inside `<application ...>`, add:

`android:usesCleartextTraffic="true"`

For a physical phone, replace `10.0.2.2` with the computer's LAN IP. For production, use HTTPS and remove the cleartext setting.
