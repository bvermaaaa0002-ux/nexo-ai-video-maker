import 'package:flutter/material.dart';
import '../widgets/glass_card.dart';
import '../widgets/gradient_button.dart';
import '../services/video_draft.dart';

class ScriptScreen extends StatefulWidget {
  final VideoDraft draft;
  const ScriptScreen({super.key, required this.draft});

  @override
  State<ScriptScreen> createState() => _ScriptScreenState();
}

class _ScriptScreenState extends State<ScriptScreen> {
  late final TextEditingController controller;

  @override
  void initState() {
    super.initState();
    controller = TextEditingController(text: widget.draft.script);
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('नई वीडियो बनाएँ')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('अपनी स्क्रिप्ट डालें',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
          const SizedBox(height: 10),
          GlassCard(
            child: TextField(
              controller: controller,
              maxLines: 14,
              maxLength: 10000,
              decoration: const InputDecoration(
                border: InputBorder.none,
                hintText: 'यहाँ अपनी पूरी स्क्रिप्ट पेस्ट करें...',
              ),
            ),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: () {
              controller.text =
                  'रात के सन्नाटे में एक पुरानी हवेली के दरवाजे अपने आप खुल गए...';
            },
            icon: const Icon(Icons.description_outlined),
            label: const Text('उदाहरण स्क्रिप्ट डालें'),
          ),
          const SizedBox(height: 24),
          GradientButton(
            text: 'आगे बढ़ें',
            icon: Icons.arrow_forward,
            onPressed: () {
              if (controller.text.trim().isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('पहले स्क्रिप्ट डालें।')),
                );
                return;
              }
              widget.draft.setScript(controller.text.trim());
              Navigator.pushNamed(context, '/settings');
            },
          ),
        ],
      ),
    );
  }
}
