import 'package:flutter/material.dart';
import '../widgets/gradient_button.dart';

class PreviewScreen extends StatelessWidget {
  const PreviewScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final output = ModalRoute.of(context)?.settings.arguments as String?;
    return Scaffold(
      appBar: AppBar(title: const Text('Video Preview')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.check_circle,
                size: 80, color: Colors.greenAccent),
            const SizedBox(height: 20),
            const Text('वीडियो तैयार है!',
                style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800)),
            const SizedBox(height: 12),
            Text(
              output ?? 'Backend ने output path नहीं भेजा।',
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white60),
            ),
            const SizedBox(height: 24),
            GradientButton(
              text: 'Export',
              icon: Icons.ios_share,
              onPressed: () => Navigator.pushNamed(context, '/export'),
            ),
          ],
        ),
      ),
    );
  }
}
